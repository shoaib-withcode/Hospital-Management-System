# Hospital Management System — Easy Setup

This is the same Java Swing + MySQL project. The Java screen/interface and existing features are kept unchanged; only the setup instructions and a simple Windows run file are added.

## What you need
1. JDK 17 or newer
2. Maven installed and available in PATH
3. MySQL Server running

## Step 1 — Create the database
1. Open MySQL Workbench.
2. Open `database/schema.sql` from this project.
3. Run the whole script (lightning button).

It creates the `hospital` database and tables and adds demo users/doctors. If your database already has data, do not drop the database.

## Step 2 — Start the program
Double-click `RUN_PROJECT.bat`. When asked, type your MySQL root password and press Enter. (The password will not be displayed while typing only if your terminal supports hidden input; this simple batch file may show typed characters.)

Or from a terminal in this folder, run:

```powershell
$env:HMS_DB_URL="jdbc:mysql://localhost:3306/hospital"
$env:HMS_DB_USER="root"
$env:HMS_DB_PASSWORD="YOUR_MYSQL_PASSWORD"
mvn clean compile exec:java
```

## Demo login
| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Receptionist | `reception` | `reception123` |
| Viewer | `viewer` | `viewer123` |

## Features kept
- Role-based login (Admin, Receptionist, Viewer)
- Add and view patients
- View doctors
- Book appointments (prevents booking the same doctor on the same date)
- Patient appointment history
- Admin-only patient removal

## Important
- MySQL must be running on the same computer using the default connection URL, unless you change `HMS_DB_URL`.
- These are demo accounts and this project is for college learning, not real patient records.
- Do not share your MySQL password or commit it to GitHub.
