@echo off
setlocal
cd /d "%~dp0"
echo Hospital Management System
set /p HMS_DB_PASSWORD=Enter MySQL root password: 
set "HMS_DB_URL=jdbc:mysql://localhost:3306/hospital"
set "HMS_DB_USER=root"
where mvn >nul 2>nul
if errorlevel 1 (
  echo ERROR: Maven was not found. Install Maven and add it to PATH, then try again.
  pause
  exit /b 1
)
echo Starting project...
mvn clean compile exec:java
pause
